-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.37 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table test4.detections
CREATE TABLE IF NOT EXISTS `detections` (
  `uid` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `detection_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gps` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test4.detections: ~0 rows (approximately)
/*!40000 ALTER TABLE `detections` DISABLE KEYS */;
/*!40000 ALTER TABLE `detections` ENABLE KEYS */;

-- Dumping structure for table test4.locations
CREATE TABLE IF NOT EXISTS `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test4.locations: ~32 rows (approximately)
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` (`id`, `parent`, `name`) VALUES
	(1, 0, 'Планета Земля'),
	(2, 1, 'Европа'),
	(3, 1, 'Азиатский регион'),
	(4, 2, 'Украина'),
	(5, 4, 'Киев'),
	(6, 4, 'Одесса'),
	(7, 4, 'Днепр'),
	(8, 3, 'Казахстан'),
	(9, 3, 'Азербайджан'),
	(10, 8, 'Almaty'),
	(11, 8, 'Aktobe'),
	(12, 9, 'Баку'),
	(13, 5, 'Ресторан "Козлята"'),
	(14, 5, 'Магазин ЕВА'),
	(15, 6, 'ООО "Нли ю"'),
	(16, 6, 'ОАО "Вальве"'),
	(17, 6, 'Одесский порт'),
	(18, 10, 'Almaty KZ'),
	(19, 10, 'Almaty RU'),
	(20, 11, 'ЦБО 201'),
	(21, 12, 'СтройИнвест'),
	(22, 12, 'НеСтройИнвест'),
	(23, 14, 'Магазин 1'),
	(24, 14, 'Магазин 2'),
	(25, 15, 'Магазин 3'),
	(26, 16, 'Магазин 4'),
	(27, 18, 'ЦБО 101'),
	(28, 18, 'ЦБО 102'),
	(29, 18, 'ЦБО 103'),
	(30, 19, 'ЦБО 104'),
	(31, 19, 'ЦБО 105'),
	(32, 19, 'ЦБО 106');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;

-- Dumping structure for table test4.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table test4.migrations: ~2 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`migration`, `batch`) VALUES
	('2017_11_11_132834_locations', 1),
	('2017_11_11_171014_detections', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
